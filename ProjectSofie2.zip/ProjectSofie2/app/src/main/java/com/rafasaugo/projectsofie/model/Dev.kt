package com.rafasaugo.projectsofie.model

class Dev {

    var title = ""
    var email = ""
    var description = ""

    override fun toString(): String {
        return "Dev(title='$title', email='$email', description='$description')"
    }

}



