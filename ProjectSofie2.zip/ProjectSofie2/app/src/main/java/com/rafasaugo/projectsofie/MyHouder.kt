package com.rafasaugo.projectsofie

import android.view.View
import androidx.recyclerview.widget.RecyclerView

class MyHouder(itemView: View) : RecyclerView.ViewHolder(itemView)